<?php

namespace App\Http\Controllers;

use App\Models\Chair;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ChairController extends Controller
{
   public function add_rule(Request $request){
        return 'working';
   }
}
