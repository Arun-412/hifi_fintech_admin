@extends('layouts.master')
@section('content')
<section style="margin-top: 110px;margin-bottom: 40px;padding: 0px 30px;">
    <div class="container-fluid">
        <div class="row">
        <h2>Welcome to HIFI FINTECH</h2>
</div>
</div>
</section>
    
@endsection