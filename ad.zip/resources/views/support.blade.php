@extends('layouts.master')
@section('content')
<section style="margin-top: 110px;margin-bottom: 40px;padding: 0px 30px;">
    <div class="container-fluid">
        <h2>Support</h2>
        <hr>
        <h4>Distributer Contact Details</h4>
        <p>Mobile: +91 63832 24535</p>
        <p>Email: arunmozhi@namv.in</p>
        <hr>
        <h4>Company Contact Details</h4>
        <p>Mobile: +91 82701 81914</p>
        <p>Email: contact@hififintech.com</p>
        <hr>
        <h4>Register a Complaint</h4>
        <p>Executive Officer: +91 63832 24535</p>
        <p>CEO: +91 63832 24535</p>
        <hr>
</div>
</section>
@endsection