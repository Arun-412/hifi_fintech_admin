@extends('layouts.master')
@section('content')
<div style="margin-top:100px;">
<h2>Wallet Approvals Coming Soon..!</h2>
</div>
@endsection