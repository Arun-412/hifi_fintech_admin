
<?php $__env->startSection('content'); ?>
<div style="margin-top:100px;"></div>
<?php if(session('failed')): ?>
    <div class="alert alert-danger"> <?php echo e(session('failed')); ?></div>
<?php endif; ?>
<table id="retailers_list" class="display nowrap" style="width:100%;">
        <thead>
            <tr>
                <th>S.No</th>
                <th>Shop Name</th>
                <th>Mobile Number</th>
                <th>Email</th>
                <th>KYC Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php if(session('dataN')): ?>
        <?php $__currentLoopData = session('dataN'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index+1); ?></td>
                <td><?php echo e($v->shop_name); ?></td>
                <td><?php echo e($v->mobile_number); ?></td>
                <td><?php echo e($v->email); ?></td>
                <?php if($v->kyc_status == 'HFY'): ?>
                <td>Completed</td>
                <?php elseif($v->kyc_status == 'HFI'): ?>
                <td>Incomplete</td>
                <?php else: ?>
                <td>Pending</td>
                <?php endif; ?>
                <td><button type="button">Deactivate</button><button type="button">Edit</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index+1); ?></td>
                <td><?php echo e($v->shop_name); ?></td>
                <td><?php echo e($v->mobile_number); ?></td>
                <td><?php echo e($v->email); ?></td>
                <?php if($v->kyc_status == 'HFY'): ?>
                <td>Completed</td>
                <?php elseif($v->kyc_status == 'HFI'): ?>
                <td>Incomplete</td>
                <?php else: ?>
                <td>Pending</td>
                <?php endif; ?>
                <td><button type="button">Deactivate</button><button type="button">Edit</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\admin\resources\views/user_management/retailers.blade.php ENDPATH**/ ?>