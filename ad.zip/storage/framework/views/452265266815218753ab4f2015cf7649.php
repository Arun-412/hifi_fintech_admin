
<?php $__env->startSection('content'); ?>
<section style="margin-top: 110px;margin-bottom: 40px;padding: 0px 30px;">
    <div class="container-fluid">
<h2>Profile</h2>
<hr>
<p>Shop Name : <b><?php echo e(Auth::user()->shop_name); ?></b></p>
<p>User Code : <b><?php echo e(Auth::user()->door_code); ?></b></p>
<p>Mobile Number : <b><?php echo e(Auth::user()->mobile_number); ?></b></p>
<p>Email : <b><?php echo e(Auth::user()->email); ?></b></p>
<p>Distributer Code : <b><?php echo e(Auth::user()->door_opened_by); ?></b></p>
<p>KYC Status : <?php if(Auth::user()->kyc_status == 'HFY'): ?><b>Completed</b><?php elseif((Auth::user()->kyc_status == 'HFI')): ?><b>Incomplete</b><?php else: ?><b>Pending</b><?php endif; ?></p>
<hr>
<h5>Charge Details</h5>
<style>
    table, th, td {
  border: 1px solid black;
}
</style>
<table>
        <tr>
            <th>S.No</th>
            <th>Services</th>
            <th>Charges</th>
        </tr>
        <tr>
            <td>1</td>
            <td>Payout</td>
            <td>5.5+GST</td>
        </tr>
</table>

</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\admin\resources\views/profile.blade.php ENDPATH**/ ?>