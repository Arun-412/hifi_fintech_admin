
<?php $__env->startSection('content'); ?>
<div style="margin-top:100px;"></div>
<?php if(session('failed')): ?>
    <div class="alert alert-danger"> <?php echo e(session('failed')); ?></div>
<?php endif; ?>
<?php if(session('dataN')): ?>
    <div class="text-center alert alert-success">New Retailer Created Successfully</div>
<?php endif; ?>
<form action="register_distributer" method="post" style="margin-top:100px;">
<?php echo csrf_field(); ?>
    <input type="text" value="<?php echo e(old('shop_name')); ?>" name="shop_name"  id="shop_name" placeholder="Enter Shop Name">
    <?php $__errorArgs = ['shop_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="tel" value="<?php echo e(old('mobile_number')); ?>" name="mobile_number"  id="mobile_number" placeholder="Enter mobile number">
    <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="email" value="<?php echo e(old('email')); ?>" name="email" id="email" placeholder="enter email">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="submit" value="Create User"> 
</form>
<table id="distributers_list" class="display nowrap" style="width:100%;">
        <thead>
            <tr>
                <th>S.No</th>
                <th>Shop Name</th>
                <th>Mobile Number</th>
                <th>Email</th>
                <th>KYC Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php if(session('dataN')): ?>
        <?php $__currentLoopData = session('dataN'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index+1); ?></td>
                <td><?php echo e($v->shop_name); ?></td>
                <td><?php echo e($v->mobile_number); ?></td>
                <td><?php echo e($v->email); ?></td>
                <?php if($v->kyc_status == 'HFY'): ?>
                <td>Completed</td>
                <?php elseif($v->kyc_status == 'HFI'): ?>
                <td>Incomplete</td>
                <?php else: ?>
                <td>Pending</td>
                <?php endif; ?>
                <td><button type="button">Deactivate</button><button type="button">Edit</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index+1); ?></td>
                <td><?php echo e($v->shop_name); ?></td>
                <td><?php echo e($v->mobile_number); ?></td>
                <td><?php echo e($v->email); ?></td>
                <?php if($v->kyc_status == 'HFY'): ?>
                <td>Completed</td>
                <?php elseif($v->kyc_status == 'HFI'): ?>
                <td>Incomplete</td>
                <?php else: ?>
                <td>Pending</td>
                <?php endif; ?>
                <td><button type="button">Deactivate</button><button type="button">Edit</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\admin\resources\views/user_management/distributers.blade.php ENDPATH**/ ?>