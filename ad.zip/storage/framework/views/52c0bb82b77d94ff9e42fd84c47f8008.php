<hr><hr><h3 style="background-color:green;color:white;">Onboarding</h3>
<form action="<?php echo e(route('Onboard_User')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Onboard_User)): ?>
        <p><?php echo e($Onboard_User); ?></p>
    <?php endif; ?>
    <input type="submit" value="Onboard User">
</form>
<form action="<?php echo e(route('Get_Services')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Get_Services)): ?>
        <p><?php echo e($Get_Services); ?></p>
    <?php endif; ?>
    <input type="submit" value="Get Services">
</form>
<form action="<?php echo e(route('Request_OTP')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Request_OTP)): ?>
        <p><?php echo e($Request_OTP); ?></p>
    <?php endif; ?>
    <input type="submit" value="Request OTP">
</form>
<form action="<?php echo e(route('Verify_User_Mobile_Number')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Verify_User_Mobile_Number)): ?>
        <p><?php echo e($Verify_User_Mobile_Number); ?></p>
    <?php endif; ?>
    <input type="submit" value="Verify User Mobile Number">
</form>
<form action="<?php echo e(route('User_Services_Enquiry')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($User_Services_Enquiry)): ?>
        <p><?php echo e($User_Services_Enquiry); ?></p>
    <?php endif; ?>
    <input type="submit" value="User Services Enquiry">
</form>
<hr><hr><h3>Payout</h3>
<form action="<?php echo e(route('Activate_Payout')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Activate_Payout)): ?>
        <p><?php echo e($Activate_Payout); ?></p>
    <?php endif; ?>
    <input style="background-color:red;color:white;" type="submit" value="Activate Payout">
</form>
<form action="<?php echo e(route('Payout_Fund_Transfer')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Payout_Fund_Transfer)): ?>
        <p><?php echo e($Payout_Fund_Transfer); ?></p>
    <?php endif; ?>
    <input type="submit" value="Payout Fund Transfer">
</form>
<form action="<?php echo e(route('Payout_Transaction_Status_By_ID')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Payout_Transaction_Status_By_ID)): ?>
        <p><?php echo e($Payout_Transaction_Status_By_ID); ?></p>
    <?php endif; ?> 
    <input style="background-color:blue;color:white;" type="submit" value="Payout Transaction Status By ID">
</form>
<form action="<?php echo e(route('Payout_Transaction_Status')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Payout_Transaction_Status)): ?>
        <p>Status Update Automatically using webhook <br>
        <?php $__currentLoopData = $Payout_Transaction_Status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($d); ?> : <?php echo e($p); ?><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
    <?php endif; ?> 
    <input style="background-color:blue;color:white;" type="submit" value="Payout Transaction Status">
</form>
<hr><hr><h3 style="background-color:green;color:white;">Money Transfer</h3>
<form action="<?php echo e(route('Get_Customer')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Get_Customer)): ?>
        <p><?php echo e($Get_Customer); ?></p>
    <?php endif; ?>
    <input type="submit" value="Get Customer">
</form>
<form action="<?php echo e(route('Create_Customer')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Create_Customer)): ?>
        <p><?php echo e($Create_Customer); ?></p>
    <?php endif; ?>
    <input type="submit" value="Create Customer">
</form>
<form action="<?php echo e(route('Verify_Customer')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Verify_Customer)): ?>
        <p><?php echo e($Verify_Customer); ?></p>
    <?php endif; ?>
    <input type="submit" value="Verify Customer">
</form>
<form action="<?php echo e(route('Get_Bank_Details')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Get_Bank_Details)): ?>
        <p><?php echo e($Get_Bank_Details); ?></p>
    <?php endif; ?>
    <input type="submit" value="Get Bank Details">
</form>
<form action="<?php echo e(route('Bank_Account_Verification')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Bank_Account_Verification)): ?>
        <p><?php echo e($Bank_Account_Verification); ?></p>
    <?php endif; ?>
    <input type="submit" value="Bank Account Verification">
</form>
<form action="<?php echo e(route('Add_Recipient')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Add_Recipient)): ?>
        <p><?php echo e($Add_Recipient); ?></p>
    <?php endif; ?>
    <input type="submit" value="Add Recipient">
</form>
<form action="<?php echo e(route('Get_Recipient')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Get_Recipient)): ?>
        <p><?php echo e($Get_Recipient); ?></p>
    <?php endif; ?>
    <input type="submit" value="Get Recipient">
</form>
<form action="<?php echo e(route('Get_List_of_Recipients')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Get_List_of_Recipients)): ?>
        <p><?php echo e($Get_List_of_Recipients); ?></p>
    <?php endif; ?>
    <input type="submit" value="Get List of Recipients">
</form>
<form action="<?php echo e(route('Initiate_Transaction')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Initiate_Transaction)): ?>
        <p><?php echo e($Initiate_Transaction); ?></p>
    <?php endif; ?>
    <input type="submit" value="Initiate Transaction">
</form>
<form action="<?php echo e(route('Transaction_Inquiry')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Transaction_Inquiry)): ?>
        <p><?php echo e($Transaction_Inquiry); ?></p>
    <?php endif; ?>
    <input type="submit" value="Transaction Inquiry">
</form>
<form action="<?php echo e(route('Refund')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Refund)): ?>
        <p><?php echo e($Refund); ?></p>
    <?php endif; ?>
    <input type="submit" value="Refund">
</form>
<form action="<?php echo e(route('Generate_QR')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Generate_QR)): ?>
        <p><?php echo e($Generate_QR); ?></p>
    <?php endif; ?>
    <input type="submit" value="Generate QR">
</form>
<form action="<?php echo e(route('Activate_QR')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Activate_QR)): ?>
        <p><?php echo e($Activate_QR); ?></p>
    <?php endif; ?>
    <input style="background-color:red;color:white;"  type="submit" value="Activate QR">
</form>
<!-- <hr><hr><h3>AePS</h3>
<form action="<?php echo e(route('Activate_AePS')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Activate_AePS)): ?>
        <p><?php echo e($Activate_AePS); ?></p>
    <?php endif; ?>
    <input style="background-color:red;color:white;" type="submit" value="Activate AePS">
</form>
<h3 style="background-color:red;color:white;">AePS E-KYC</h3>
<form action="<?php echo e(route('AePS_KYC_OTP_Request')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($AePS_KYC_OTP_Request)): ?>
        <p><?php echo e($AePS_KYC_OTP_Request); ?></p>
    <?php endif; ?>
    <input type="submit" value="AePS KYC OTP Request">
</form>
<form action="<?php echo e(route('AePS_KYC_OTP_Verify')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($AePS_KYC_OTP_Verify)): ?>
        <p><?php echo e($AePS_KYC_OTP_Verify); ?></p>
    <?php endif; ?>
    <input type="submit" value="AePS KYC OTP Verify">
</form>
<form action="<?php echo e(route('AePS_KYC_Biometric')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($AePS_KYC_Biometric)): ?>
        <p><?php echo e($AePS_KYC_Biometric); ?></p>
    <?php endif; ?>
    <input type="submit" value="AePS KYC Biometric">
</form>
<form action="<?php echo e(route('AePS_Daily_Auth')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($AePS_Daily_Auth)): ?>
        <p><?php echo e($AePS_Daily_Auth); ?></p>
    <?php endif; ?>
    <input type="submit" value="AePS Daily Auth">
</form>
<hr><h3>AePS API</h3>
<form action="<?php echo e(route('AePS_Daily_Auth')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($AePS_Daily_Auth)): ?>
        <p><?php echo e($AePS_Daily_Auth); ?></p>
    <?php endif; ?>
    <input type="submit" value="AePS Daily Auth">
</form> -->
<hr> <hr><h3>Pan Verification</h3>
<form action="<?php echo e(route('Pan_Verify')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Pan_Verify)): ?>
        <p><?php echo e($Pan_Verify); ?></p>
    <?php endif; ?>
    <input type="submit" value="Verify PAN">
</form>
<hr><h3>Aadhar Verification</h3>
<form action="<?php echo e(route('Aadhar_Consent')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Aadhar_Consent)): ?>
        <p><?php echo e($Aadhar_Consent); ?></p>
    <?php endif; ?>
    <input type="submit" value="Aadhar Consent">
</form>
<form action="<?php echo e(route('Aadhaar_OTP')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Aadhaar_OTP)): ?>
        <p><?php echo e($Aadhaar_OTP); ?></p>
    <?php endif; ?>
    <input style="background-color:red;color:white;"  type="submit" value="Aadhaar OTP">
</form>
<form action="<?php echo e(route('Aadhaar_File')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(!empty($Aadhaar_File)): ?>
        <p><?php echo e($Aadhaar_File); ?></p>
    <?php endif; ?>
    <input style="background-color:red;color:white;"  type="submit" value="Aadhaar File">
</form>

<?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\admin\resources\views/eko1.blade.php ENDPATH**/ ?>