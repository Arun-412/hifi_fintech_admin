
<form action="logout" method="post">
    <?php echo csrf_field(); ?>
    <h2>Welcome to HIFI FINTECH</h2>

<p><?php echo e(Auth::user()); ?></p>

<button type="submit" value="Logout">Logout</button>
</form><?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\hifi_fintech\resources\views/dashboard.blade.php ENDPATH**/ ?>