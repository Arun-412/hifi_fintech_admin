
<?php $__env->startSection('content'); ?>
<section style="margin-top: 110px;margin-bottom: 40px;padding: 0px 30px;">
    <div class="container-fluid">
    <h2>Service Providers</h2>
    <div class="row mb-5">
            <div class="col-sm-12 col-md-12 col-xs-12">
                <div class="payout-box">
                    <h4 style="float:left;">Providers list</h4>
                    <table id="providers_list_table" class="table display nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th scope="col">S.No</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Mobile</th>
                                <th scope="col">Status</th>
                                <!-- <th scope="col">Action</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['providers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><input type="hidden" name="provider_cd" value="<?php echo e($v->room_code); ?>">
                                <td><?php echo e($index+1); ?></td>
                                <td><?php echo e($v->room_name); ?></td>
                                <td><?php echo e($v->room_email); ?></td>
                                <td><?php echo e($v->room_mobile); ?></td>
                                <?php if($v->room_status == 'HFY'): ?>
                                <td>Activated</td>
                                <!-- <td><button>Deactivate</button></td> -->
                                <?php else: ?>
                                <td>Deacivated</td>
                                <!-- <td><button>Activate</button></td> -->
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-xs-12">
                <div class="payout-box">
                    <h4 style="float:left;">Service list</h4>
                    <table id="services_list_table" class="table display nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th scope="col">S.No</th>
                                <th scope="col">Provider Name</th>
                                <th scope="col">Service Name</th>
                                <th scope="col">Status</th>
                                <!-- <th scope="col">Action</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr> <input type="hidden" name="service_cd" value="<?php echo e($v->counter_code); ?>">
                                <td><?php echo e($index+1); ?></td>
                                <?php if($v->room_code == 'HFAPVR23EKO011023'): ?>
                                <td>Eko India Financial Services</td>
                                <?php endif; ?>
                                <td><?php echo e($v->counter_name); ?></td>
                                <?php if($v->counter_status == 'HFY'): ?>
                                <td>Activated</td>
                                <!-- <td><button>Deactivate</button></td> -->
                                <?php else: ?>
                                <td>Deacivated</td>
                                <!-- <td><button>Activate</button></td> -->
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\admin\resources\views/services.blade.php ENDPATH**/ ?>