<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>HIFI FINTECH</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <link rel="style" href="<?php echo e(asset('assets/css/style.scss')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-grid.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-grid.rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-reboot.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-utilities.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
</head>
<body><?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\hifi_fintech\resources\views/layouts/header.blade.php ENDPATH**/ ?>