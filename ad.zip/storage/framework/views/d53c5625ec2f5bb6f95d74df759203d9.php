
<?php $__env->startSection('content'); ?>
<section style="margin-top: 110px;margin-bottom: 40px;padding: 0px 30px;">
    <div class="container-fluid">
        <div class="row">
        <h2>Welcome to HIFI FINTECH</h2>
</div>
</div>
</section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\admin\resources\views/dashboard.blade.php ENDPATH**/ ?>