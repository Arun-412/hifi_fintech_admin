<script type="script" src="<?php echo e(asset('assets/js/bootstrap.bundle.js')); ?>"></script>
<script type="script" src="<?php echo e(asset('assets/js/bootstrap.js')); ?>"></script>
<script type="script" src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src=" <?php echo e(URL::asset('assets/js/script.js')); ?>"></script>
</body>
</html><?php /**PATH D:\xampp-27-07-22\htdocs\NAMV\learned\hifi_fintech\resources\views/layouts/footer.blade.php ENDPATH**/ ?>